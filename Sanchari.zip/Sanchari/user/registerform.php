<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<body style="background-color:powderblue;">
    
    <div id="register">
        <h3 class="text-center text-white pt-5">Online Ambulance</h3>
        <div class="container">
            <div id="register-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-12">
                        <form id="register-form" class="form" action="" method="post">
                            <h3 class="text-center text-info">Register</h3>
                            <div class="form-group">
                                <label for="name" class="text-info">Name:</label><br>
                                <input type="text" name="name" id="name" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="email" class="text-info">Email:</label><br>
                                <input type="email" name="email" id="email" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="phone" class="text-info">Pone Number:</label><br>
                                <input type="text" name="phonenum" id="phonenum" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="addr" class="text-info">Address:</label><br>
                                <input type="textarea" name="addr" id="addr" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="addr" class="text-info">Pincode:</label><br>
                                <input type="textarea" name="addr" id="addr" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="password" class="text-info">Password:</label><br>
                                <input type="text" name="password" id="password" class="form-control">
                            </div>
                            <div>
                                   <button class="from-group" name="submit"><a href="login.php">Submit</a></button>
                            </div>
                         
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
	 
	 