<html>

   <head>
      <title>HTML Frames</title>
      <style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}
.heading{
font-size: 47px;
color:white;
}

.topnav a {
  float: right;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}
.para{
    color=balck;
    font-size: 30px;
    text-align: center;
}
.imaf{
   width: 150px;
   height: 150px;
}
</style>
   </head>
	<body style="background-color:powderblue;">
           <div class="topnav">
  <p class="heading">Online Ambulance</p>
  
  <a href="about.php">About Us</a>
    <a href="user/login.php">Logout</a>
  
</div>
           <frameset rows="50%,50%">  
               <frame>Hii</frame>  
               <frame>   hello</frame>  
   </frameset> 
   
</html>